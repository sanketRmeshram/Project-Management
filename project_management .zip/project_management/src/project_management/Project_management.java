/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_management;

/**
 *
 * @author sanket
 */
public class Project_management {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //new Sign_up_tm().setVisible(true);
        new Sign_in().setVisible(true);
        //new expense_management().setVisible(true);
        //new task_prof().setVisible(true);
        //new reimbursement().setVisible(true);
        //new expense_management().setVisible(true);
       // new meet_prof().setVisible(true);
        //new Meet_stud().setVisible(true);
        //new Sign_up_prof().setVisible(true);
        //new stud_task_report().setVisible(true);
        //new team_members().setVisible(true);
        // TODO code application logic here
      //  new prev_leav2().setVisible(true);
        //new leave_prof1().setVisible(true);
        //new task_report().setVisible(true);
    }
    
}
